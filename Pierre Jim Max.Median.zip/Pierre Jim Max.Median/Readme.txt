Nom: Pirre
Prenom: Jim Max
Code:33450
Discipline: Science Informatique
Niveau D'etude: 2eAnnee 
Vacation: Median